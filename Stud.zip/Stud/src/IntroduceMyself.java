import java.lang.reflect.Field;
abstract class IntroduceMyself {
    abstract String toCSV();
}