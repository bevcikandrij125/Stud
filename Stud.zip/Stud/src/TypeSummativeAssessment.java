//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

enum TypeSummativeAssessment {
    CREDIT,
    EXAM;

    private TypeSummativeAssessment() {
    }
}
